<?
# See deferred.doc
global $IP;
include_once( "$IP/UserUpdate.php" );
include_once( "$IP/ViewCountUpdate.php" );
include_once( "$IP/SiteStatsUpdate.php" );
include_once( "$IP/LinksUpdate.php" );
include_once( "$IP/SearchUpdate.php" );
include_once( "$IP/UserTalkUpdate.php" );

?>
