<?
# See language.doc

include_once( "Utf8Case.php" );

class LanguageMl extends LanguageUtf8 {
	# Inherit everything

}
?>
