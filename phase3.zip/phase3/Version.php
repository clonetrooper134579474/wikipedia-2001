<?
# This file is copied to the install directory so that
# later update scripts will be able to use it to determine
# what they need to update. The version number here must
# be updated any time you make a change that requires
# the update to do anything other than copy the new files
# over, such as changing the database layout. If you
# change this version number, you should also update the
# update.php script.
#

$wgSoftwareRevision = 1001;
?>
