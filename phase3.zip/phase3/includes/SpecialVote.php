<?

function wfSpecialVote()
{
	global $wgUser, $wgOut;

	$wgOut->addHTML( "<p>(TODO: Vote)" );
}

?>
